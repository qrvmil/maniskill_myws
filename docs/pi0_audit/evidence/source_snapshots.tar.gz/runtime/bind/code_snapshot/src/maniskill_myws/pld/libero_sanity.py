"""Frozen-base audit contracts, deliberately separate from V2/V3/V4 gates."""
from pathlib import Path
import hashlib
import numpy as np
from .libero_protocol import file_sha256, task_key

UPDATES = (0, 500, 1000, 2000, 3001)


def evaluation_seeds(config, model):
    if model not in (*UPDATES, 'positive_control'):
        raise ValueError('Unregistered model/update')
    seeds = tuple(config['seeds'])
    if seeds != tuple(range(9000, 9050)) or tuple(config['optimizer_updates']) != UPDATES:
        raise ValueError('Audit seeds or optimizer milestones changed')
    return seeds


def completed_updates(loop_index, state_step):
    """Check the actual optimizer counter, never infer updates from a filename."""
    if int(state_step) != loop_index + 1:
        raise ValueError('Optimizer update counter disagrees with loop index')
    return int(state_step)


def require_d0_binding(binding, config):
    if (binding['training_tasks'] != [task_key(config['tasks'][0])]
            or binding['num_demonstrations'] != 50 or binding['transitions'] != 5832
            or binding['pretrained_checkpoint'] != 'gs://openpi-assets/checkpoints/pi0_base'):
        raise ValueError('D0-only training provenance mismatch')
    if file_sha256(binding['normalization_path']) != binding['normalization_sha256']:
        raise ValueError('D0 normalization changed')


def model_contract(config, model, binding):
    evaluation_seeds(config, model)
    if model == 'positive_control':
        return {**config['positive_control'], 'normalization_path': None}
    return dict(config='pi0_libero_seen_lora32', optimizer_updates=model,
                normalization_path=binding['normalization_path'], purpose='d0_trajectory')


class PromptCheckedPolicy:
    """Assert/log the exact prompt immediately before official tokenization.

    Wrap the actual Policy input transform, preserving its transform order,
    numerical values, sampling noise and output transforms.
    """
    def __init__(self, policy, expected_prompt):
        from openpi import transforms
        self.policy = policy
        self.expected_prompt = expected_prompt
        self.calls = 0
        self.evidence = {}
        original = policy._input_transform
        chain = list(original.transforms)
        if sum(isinstance(t, transforms.TokenizePrompt) for t in chain) != 1:
            raise ValueError('Expected exactly one official prompt tokenizer')
        def checked_input(data):
            for transform in chain:
                if isinstance(transform, transforms.TokenizePrompt):
                    prompt = data.get('prompt')
                    if prompt != self.expected_prompt():
                        raise ValueError(f'Inference prompt mismatch: {prompt!r}')
                    data = transform(data)
                    digest = hashlib.sha256(np.asarray(data['tokenized_prompt']).tobytes()).hexdigest()
                    old = self.evidence.setdefault(prompt, dict(calls=0, token_sha256=digest))
                    if old['token_sha256'] != digest:
                        raise ValueError('Tokenized prompt changed for fixed instruction')
                    old['calls'] += 1
                    self.calls += 1
                else:
                    data = transform(data)
            return data
        policy._input_transform = checked_input

    def infer(self, obs, *, noise):
        before = self.calls
        result = self.policy.infer(obs, noise=noise)
        if self.calls != before + 1:
            raise ValueError('Real inference did not traverse checked prompt path')
        return result


def wilson(successes, n):
    if not 0 <= successes <= n or n < 1:
        raise ValueError('Invalid binomial count')
    z = 1.959963984540054
    p = successes / n
    center = (p + z*z/(2*n))/(1+z*z/n)
    half = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/(1+z*z/n)
    return [max(0., float(center-half)), min(1., float(center+half))]
